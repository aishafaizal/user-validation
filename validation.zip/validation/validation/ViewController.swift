//
//  ViewController.swift
//  validation
//
//  Created by Aisha Khan on 10/15/21.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var textValidityLabel: UILabel!
    
    @IBOutlet weak var emailLabel: UILabel!
    
    @IBOutlet weak var passwordLabel: UILabel!
    
    
    @IBOutlet weak var nameLabel: UILabel!
    
    @IBOutlet weak var phoneLabel: UILabel!
    
    @IBOutlet weak var emailTextField: UITextField!
   
    @IBOutlet weak var passwordTextField: UITextField!
    
    @IBOutlet weak var nameTextField: UITextField!
    
    @IBOutlet weak var phoneNumberTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
    
    @IBAction func nameAction(_ sender: Any) {
        let text = nameTextField.text ?? ""
        if text.isValidName() {
            nameTextField.textColor = UIColor.black
            nameLabel.text = "Valid Name"
        } else {
            nameTextField.textColor = UIColor.red
            nameLabel.text = "Invalid Name"
        }
        
    }
    
    @IBAction func emailAction(_ sender: Any) {
        let text = emailTextField.text ?? ""
        if text.isValidEmail() {
            emailTextField.textColor = UIColor.black
            emailLabel.text = "Valid Email"
        } else {
            emailTextField.textColor = UIColor.red
            emailLabel.text = "Invalid Email"
        }
        
    }
    
    @IBAction func phoneAction(_ sender: Any) {
        let text = phoneNumberTextField.text ?? ""
        if text.isValidPhone() {
            phoneNumberTextField.textColor = UIColor.black
            phoneLabel.text = "Valid Phone Number"
        } else {
            phoneNumberTextField.textColor = UIColor.red
            phoneLabel.text = "Invalid Phone Number"
        }
        
    }
    
    @IBAction func passwordAction(_ sender: Any) {
        let text = passwordTextField.text ?? ""
        if text.isValidPassword() {
            passwordTextField.textColor = UIColor.black
            passwordLabel.text = "Strong Password"
        } else {
            passwordTextField.textColor = UIColor.red
            passwordLabel.text = "Weak Password"
        }
        
    }


}

extension String {
    func isValidName() -> Bool {
        let theRegex = "^[a-zA-Z-]+ ?.* [a-zA-Z-]+$"
        let thePred = NSPredicate(format: "SELF MATCHES %@", theRegex)
        return thePred.evaluate(with: self)
    }
    
    func isValidEmail() -> Bool {
        let theRegex = "[a-zA-Z0-9._%+-\\_]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,64}"
        let thePred = NSPredicate(format: "SELF MATCHES %@", theRegex)
        return thePred.evaluate(with: self)
    }
    
    func isValidPhone() -> Bool {
        let theRegex = "^[0-9+]{0,1}+[0-9]{5,16}$"
        let thePred = NSPredicate(format: "SELF MATCHES %@", theRegex)
        return thePred.evaluate(with: self)
    }
    
    func isValidPassword() -> Bool {
        let theRegex = "(?=.*[A-Z])(?=.*[0-9])(?=.*[a-z])(?=.*[ !$%&?._-]).{7,}"
        let thePred = NSPredicate(format: "SELF MATCHES %@", theRegex)
        return thePred.evaluate(with: self)
    }
}
